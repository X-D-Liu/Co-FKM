clear all;close all;
clc;

load X.mat

label=[ones(200,1)*1;ones(200,1)*2;ones(200,1)*3;ones(200,1)*4;ones(200,1)*5;ones(200,1)*6;ones(200,1)*7;ones(200,1)*8;ones(200,1)*9;ones(200,1)*10];


R=length(X); % Number of view

C=length(unique(label)); 
ETA=3; 
BETA=1.1; 
TAO=1.5;
e=0.001;
t_max=1;

%% MEMBERSHIP INITIALIZATION

for r=1:R
    [N(r),D(r)]=size(X{r});
    U{r}=rand(C,N(r));
    
    U_sum{r}=sum(U{r});
    U{r}=U{r}./repmat(U_sum{r},C,1);
end                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
U0=U;

for t=1:t_max
    
%% CALCULATE CLUSTER CENTERS FOR EACH VIEW      
    for r=1:R
        for i=1:C 
            V_up=0;V_down=0;
            for j=1:N 
                temp1=0;
                for rr=1:R
                    if rr~=r
                        temp1=temp1+U{rr}(i,j).^BETA;
                    end
                end
                  V_up=V_up+ ( ((1-ETA)*U{r}(i,j).^BETA) + ((ETA/(R-1))*temp1) ) *X{r}(j,:); % Size X{r}(j,:) =>> [1 47]
                  V_down=V_down+ ( ((1-ETA)*U{r}(i,j).^BETA) + ((ETA/(R-1))*temp1) );                                                               
            end
            V{r}(i,:)=V_up./V_down; 
        end
    end
    

    
 %% UPDATE MEMBERSHIP
    
    for r=1:R
        for i=1:C
            for j=1:N
                
                temp2=0;
                for rr=1:R
                    if rr~=r
                        temp2=temp2+GetDistance(X{rr}(j,:),V{rr}(i,:));
                    end
                end
                U_up=((1-ETA)*GetDistance(X{r}(j,:),V{r}(i,:))+(ETA/(R-1)*temp2)).^(1/(1-BETA));
                
                U_down=0;
                for h=1:C
                    temp3=0;
                    for rr=1:R
                        if rr~=r
                        temp3=temp3+GetDistance(X{rr}(j,:),V{rr}(h,:));
                        end
                    end
                    U_down=U_down+((1-ETA)*GetDistance(X{r}(j,:),V{r}(h,:))+(ETA/(R-1)*temp3)).^(1/(1-BETA));
                end
                
                U{r}(i,j)=U_up./U_down; 
            end
        end
    end
    
      

        for r=1:R
            cost_temp(r)=sum(sum(((U0{r}-U{r}).^2))).^0.5;    
        end
        cost(t)=sum(cost_temp);
        fprintf('rate = %d, fitness = %f\n', t, cost(t));
        if t>1,
            if abs(cost(t)-cost(t-1))<e
                break;
            end
        end
   end         

    UU=(U{1}.*U{2}.*U{3}.*U{4}.*U{5}.*U{6}).^(1/R);
 
clust=[];
for i=1:2000
    [num idx]=max(UU(:,i));
    clust=[clust;idx];
end

    AR=1-ErrorRate(label,clust,C)/1474   
